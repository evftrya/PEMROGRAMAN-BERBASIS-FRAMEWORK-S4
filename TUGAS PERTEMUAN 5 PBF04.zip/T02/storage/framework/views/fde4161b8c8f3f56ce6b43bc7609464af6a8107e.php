

<?php $__env->startSection('image'); ?>
<?php echo e($foto); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('namaHero'); ?>
<?php echo e($nama); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('slogan'); ?>
<?php echo e($theSlogan); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <img src="https://i.pinimg.com/736x/94/6e/23/946e232d4fcc5c0fcd3fc6226a320ebf.jpg" alt="">
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APRIBADI\EVI FITRIYA\ITTELKOM\SEMESTER 4\PEM FRAMWORK\T02\resources\views/IronMan.blade.php ENDPATH**/ ?>