<html>
    <head>
        
    </head>
    <body>
        <p><?php echo e($coba); ?></p>
        <a href="<?php echo e(url('/tahun')); ?>">Masuk tahun</a>

    </body>
</html><?php /**PATH C:\APRIBADI\EVI FITRIYA\ITTELKOM\SEMESTER 4\PEM FRAMWORK\T02\resources\views/try.blade.php ENDPATH**/ ?>