

<?php $__env->startSection('image'); ?>
<?php echo e($foto); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('namaHero'); ?>
<?php echo e($nama); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('slogan'); ?>
<?php echo e($theSlogan); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e($what); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field($put); ?>
        <!-- untuk menlindungi dari eksploitasi -->
        <div>
            <label for="">Status</label>
            <input type="text" name="status" value="<?php echo e($istatus); ?>">
        </div>
        <div>
            <label for="">Name</label>
            <input type="text" name="name" value="<?php echo e($inama); ?>">
        </div>
        <div>
            <label for="">Short Quotes</label>
            <input type="text" name="slogan" value="<?php echo e($islogan); ?>">
        </div>
        <div>
            <label for="">Link Image</label>
            <input type="text" name="image" value="<?php echo e($ifoto); ?>">
        </div>
        <input type="submit" value ="Save">
        
        
    </form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APRIBADI\EVI FITRIYA\ITTELKOM\SEMESTER 4\PEM FRAMWORK\T02\resources\views/new.blade.php ENDPATH**/ ?>