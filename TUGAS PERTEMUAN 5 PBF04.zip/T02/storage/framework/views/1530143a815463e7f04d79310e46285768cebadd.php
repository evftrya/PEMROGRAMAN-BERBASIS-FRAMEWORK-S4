<form method="POST" action="<?php echo $__env->yieldContent('what'); ?>">
        <?php echo csrf_field(); ?>
        <!-- untuk menlindungi dari eksploitasi -->
        <div>
            <label for="">Status</label>
            <input type="text" name="status" value="">
        </div>
        <div>
            <label for="">Name</label>
            <input type="text" name="name" value="">
        </div>
        <div>
            <label for="">Short Quotes</label>
            <input type="text" name="slogan" value="">
        </div>
        <div>
            <label for="">Link Image</label>
            <input type="text" name="image" value="">
        </div>
        <input type="submit">
        
    </form><?php /**PATH C:\APRIBADI\EVI FITRIYA\ITTELKOM\SEMESTER 4\PEM FRAMWORK\T02\resources\views/layouts/formTemplate.blade.php ENDPATH**/ ?>