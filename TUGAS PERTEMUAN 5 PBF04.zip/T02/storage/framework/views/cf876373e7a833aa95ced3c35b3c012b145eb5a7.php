

<?php $__env->startSection('image'); ?>
<?php echo e($foto); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('namaHero'); ?>
<?php echo e($nama); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('slogan'); ?>
<?php echo e($theSlogan); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio labore pariatur voluptas vero amet quos, similique consequuntur adipisci laudantium vel mollitia perspiciatis recusandae minima expedita enim? Possimus repellendus magni vero!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio labore pariatur voluptas vero amet quos, similique consequuntur adipisci laudantium vel mollitia perspiciatis recusandae minima expedita enim? Possimus repellendus magni vero!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio labore pariatur voluptas vero amet quos, similique consequuntur adipisci laudantium vel mollitia perspiciatis recusandae minima expedita enim? Possimus repellendus magni vero!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio labore pariatur voluptas vero amet quos, similique consequuntur adipisci laudantium vel mollitia perspiciatis recusandae minima expedita enim? Possimus repellendus magni vero!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio labore pariatur voluptas vero amet quos, similique consequuntur adipisci laudantium vel mollitia perspiciatis recusandae minima expedita enim? Possimus repellendus magni vero!</p>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APRIBADI\EVI FITRIYA\ITTELKOM\SEMESTER 4\PEM FRAMWORK\T02\resources\views/DoctorStrange.blade.php ENDPATH**/ ?>