

<?php $__env->startSection('image'); ?>
<?php echo e($foto); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('namaHero'); ?>
<?php echo e($nama); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('slogan'); ?>
<?php echo e($theSlogan); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if($pjg>0): ?>
    <?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a id="theDetil" href="<?php echo e(route('Detail',['status'=>$hero['status']])); ?>">
        <p id='detil' ><?php echo e($hero['status']); ?></p>
    </a>
    <a id="theDetilEdit" href="<?php echo e(route('Edit',['id'=>$hero['id']])); ?>" >
        <p id='detiledit' hidden=true><?php echo e($hero['status']); ?></p>
    </a>
    <a id="theDetilDelete" href="<?php echo e(route('Delete',['id'=>$hero['id']])); ?>">
        <p id='detildelete' hidden=true><?php echo e($hero['status']); ?></p>
    </a>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p>Belum ada hero lain</p>
<?php endif; ?>

    <div class="edit-button">
        <button>
            <span class="edit-icon">&#9998</span>
        </button>
    </div>
    <div class="delete-button">
        <button>
        <span class="delete-icon">&#128465</span>
        </button>
    </div>
    <script src="/assets/js/others.js"></script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APRIBADI\EVI FITRIYA\ITTELKOM\SEMESTER 4\PEM FRAMWORK\T02\resources\views/others.blade.php ENDPATH**/ ?>