<form method="<?php echo e($postput); ?>" action="/<?php echo e($what); ?>">
        <?php echo csrf_field(); ?>
        <!-- untuk menlindungi dari eksploitasi -->
        <div>
            <label for="">Status</label>
            <input type="text" name="status" value="<?php echo e($istatus); ?>">
        </div>
        <div>
            <label for="">Name</label>
            <input type="text" name="name" value="<?php echo e($inama); ?>">
        </div>
        <div>
            <label for="">Short Quotes</label>
            <input type="text" name="slogan" value="<?php echo e($islogan); ?>">
        </div>
        <div>
            <label for="">Link Image</label>
            <input type="text" name="image" value="<?php echo e($ifoto); ?>">
        </div>
        <input type="submit">
        
    </form><?php /**PATH C:\APRIBADI\EVI FITRIYA\ITTELKOM\SEMESTER 4\PEM FRAMWORK\T02\resources\views/components/formTemplate.blade.php ENDPATH**/ ?>