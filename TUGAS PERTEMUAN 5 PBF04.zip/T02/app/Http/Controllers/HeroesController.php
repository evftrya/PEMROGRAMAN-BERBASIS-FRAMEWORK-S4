<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Heroes;
use App\Http\Controllers\Index;
use App\Http\Controllers\Others;

class HeroesController extends Controller
{
    public function index(){
        $hero = Heroes::orderBy('id','desc')->paginate(5);
        return view('tes',['foto'=>$hero['image'],'nama'=>$hero['name'],'theSlogan'=>$hero['slogan'],'navbar'=>Heroes::getAll(),compact('hero')]);
    }
    public function store(Request $request, Index $index){
        // dd($request->all());

        $request->validate([
            'name'  => 'required',
            'status'=> 'required',
            'slogan'=> 'required',
            'image' => 'required'
        ]);
        $hero = new Heroes;
        $hero->name = $request->input('name');
        $hero->id = count(Heroes::all())+1;
        $hero->status = $request->status;
        $hero->slogan = $request->slogan;
        $hero->image = $request->image;
        $hero->save();

        return $index->forNew();
    }

    public function show(Heroes $heroes){
        return view('hero.show',compact('hero'));
    }

    public function edit(Heroes $heroes){
        return view('hero.edit',compact('hero'));
    }

    public function update($id, Request $req, Others $contOthers){
        
        $req->validate([
            'name'      => 'required',
            'status'    => 'required',
            'slogan'    => 'required',
            'image'     => 'required'
        ]);

        $hero = Heroes::firstWhere('id',$id);
        $hero->name = $req->name;
        $hero->status = $req->status;
        $hero->slogan = $req->slogan;
        $hero->image = $req->image;
        $hero->save();

        return $contOthers->forEdit($hero->id);
    }

    public function destroy($id,Heroes $hero,Index $index){
        $hero = Heroes::firstWhere('id',$id);
        $hero->delete();
        return $index->forOthers();
    }
}
