<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Heroes;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Heroes>
 */
class HeroesFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'id' => fake()->numerify(),
            'status' => fake()->sentence(2,true),
            'name' => fake()->name(),
            'slogan' => fake()->sentence(7,true),
            'image' => 'https://i.pinimg.com/736x/6f/02/8b/6f028bbc523513ee386653b021e17099.jpg'
        ];
    }
}
