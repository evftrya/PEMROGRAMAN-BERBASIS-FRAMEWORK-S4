@extends('layouts.template')

@section('image')
{{$foto}}
@endsection

@section('namaHero')
{{$nama}}
@endsection

@section('slogan')
{{$theSlogan}}
@endsection

@section('content')
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio labore pariatur voluptas vero amet quos, similique consequuntur adipisci laudantium vel mollitia perspiciatis recusandae minima expedita enim? Possimus repellendus magni vero!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio labore pariatur voluptas vero amet quos, similique consequuntur adipisci laudantium vel mollitia perspiciatis recusandae minima expedita enim? Possimus repellendus magni vero!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio labore pariatur voluptas vero amet quos, similique consequuntur adipisci laudantium vel mollitia perspiciatis recusandae minima expedita enim? Possimus repellendus magni vero!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio labore pariatur voluptas vero amet quos, similique consequuntur adipisci laudantium vel mollitia perspiciatis recusandae minima expedita enim? Possimus repellendus magni vero!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio labore pariatur voluptas vero amet quos, similique consequuntur adipisci laudantium vel mollitia perspiciatis recusandae minima expedita enim? Possimus repellendus magni vero!</p>

@endsection


