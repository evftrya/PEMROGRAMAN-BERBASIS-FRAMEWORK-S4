@extends('layouts.template')

@section('image')
{{$foto}}
@endsection

@section('namaHero')
{{$nama}}
@endsection

@section('slogan')
{{$theSlogan}}
@endsection

@section('content')
    <img src="https://i.pinimg.com/736x/94/6e/23/946e232d4fcc5c0fcd3fc6226a320ebf.jpg" alt="">
@endsection


