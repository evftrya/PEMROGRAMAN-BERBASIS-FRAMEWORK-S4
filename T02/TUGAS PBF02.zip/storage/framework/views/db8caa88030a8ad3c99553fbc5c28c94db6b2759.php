

<?php $__env->startSection('image'); ?>
<?php echo e('https://i.pinimg.com/564x/19/47/2a/19472a9e7161d59994ce3282fea67f93.jpg'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('namaHero'); ?>
<?php echo e('Others'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('slogan'); ?>
<?php echo e('Blip'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="theDetil" href="<?php echo e(route('Detail',['status'=>$hero['status']])); ?>"> 
        <p><?php echo e($hero['status']); ?></p>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APRIBADI\EVI FITRIYA\ITTELKOM\SEMESTER 4\PEM FRAMWORK\T02\resources\views/Others.blade.php ENDPATH**/ ?>